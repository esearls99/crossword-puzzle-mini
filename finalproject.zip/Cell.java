public class Cell {
    private boolean isBlack;
    private boolean isBeginVertWord;
    private boolean isBeginHorizWord;
    private String output;

    public Cell() {
        this.isBlack = false;
        this.isBeginHorizWord = false;
        this.isBeginHorizWord = false;
        this.output = "";
    }

    
    public boolean getIsBlack() {
        return this.isBlack;
    }

    public boolean isIsBlack() {
        return this.isBlack;
    }

    public boolean getIsBeginVertWord() {
        return this.isBeginVertWord;
    }

    public boolean isIsBeginVertWord() {
        return this.isBeginVertWord;
    }

    public boolean getIsBeginHorizWord() {
        return this.isBeginHorizWord;
    }

    public boolean isIsBeginHorizWord() {
        return this.isBeginHorizWord;
    }

    public String getOutput() {
        return this.output;
    }
    public void setOutput(String word) {
        this.output = word;
    }

}