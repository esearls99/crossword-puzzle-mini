public class Crossword {
    // String flag; used to generate categories. Might be used in with more
    // developed wordbank.

    public static void main(String[] args) {
       // int n = Integer.parseInt(args[0]);
        GeneratedGrid genGrid = new GeneratedGrid();
        genGrid.testInput(genGrid.wordbank);
        PrintGrid.noGraphicsPrint(genGrid.grid);
        // genGrid.grid[0][0].setOutput("word");
        
        if (genGrid.isComplete()) {
            System.out.println("True");
        }
        else {
            System.out.println("False");
        }


    }

}