import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Dimension;

public class PrintGrid {//extends JPanel { // this will later include graphical printing
    public static void noGraphicsPrint(Cell[][] grid) {
        for (int i = 0; i < GeneratedGrid.N; i++) {
            for (int j = 0; j < GeneratedGrid.N; j++) {
                System.out.printf("%s ", grid[i][j].getOutput());
            }
            System.out.println();
        }
    }
}
