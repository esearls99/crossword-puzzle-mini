import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.*;

public class GeneratedGrid {
    ArrayList<String> wordbank;
    public final static int N = 7;
    public Cell[][] grid = new Cell[N][N];

    public GeneratedGrid() {
        this.wordbank = wordScanner("wordbank.txt");
        this.initializeCells(this.grid);

    }

    public void wordInput(ArrayList<String> wordbank) { // main word inputting method
        for (int i = 0; i < N; i++) {
            String word = chooseWord(wordbank);
            this.insertWord(word, i);
            ArrayList<ArrayList<String>> columns = new ArrayList<ArrayList<String>>(N);
            for (int j = 0; j < N; j++) {
                columns.add(possibleWords(j, wordbank));
            }
            for (int k = 0; k < N; k++) {
                if (columns.get(k).isEmpty()) {
                    this.clearGrid();
                    break;
                }
            }
        }
        if (this.isComplete()) {
        } else {
            this.wordInput(wordbank);
        }
    }

    public void testInput(ArrayList<String> wordbank) {
        for (int i = 0; i < N; i++) {
            this.insertWord(chooseWord(wordbank), i);
        }
    }

    private void insertWord(String word, int index) {
        String[] chars = word.split("(?!^)");
        for (int i = 0; i < N; i++) {
            this.grid[i][index].setOutput(chars[i]);

        }
    }

    private void clearGrid() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++)
                this.grid[i][j].setOutput("");
        }
    }

    private void initializeCells(Cell[][] grid) {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                grid[i][j] = new Cell();
            }
        }
    }

    public boolean isComplete() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (this.grid[i][j].getOutput().equals("")) {
                    return false;
                }
            }
        }
        return true;

    }

    public ArrayList<String> possibleWords(int index, ArrayList<String> wordbank) {
        String start = "";
        for (int i = 0; i < N; i++) {
            start = start + this.grid[index][i].getOutput();
        }
        start.trim();
        String pattern = "^" + start;
        ArrayList<String> goodWords = new ArrayList<String>();

        for (int i = 0; i < wordbank.size(); i++) {
            if (Pattern.matches(wordbank.get(i), pattern)) {
                goodWords.add(wordbank.get(i));
            }

        }
        return goodWords;
    }

    public static String chooseWord(ArrayList<String> wordbank) {
        Random rand = new Random();
        int index = rand.nextInt(wordbank.size());
        return wordbank.get(index);
    }

    private static ArrayList<String> wordScanner(String filename) {
        ArrayList<String> wordbank = new ArrayList<String>();
        try {
            File file = new File(filename);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNext()) {
                String word = scanner.next();
                if (word.length() == N) {
                    wordbank.add(word);

                }
            }
        } catch (FileNotFoundException f) {
            System.out.println("File not found");
        }

        return wordbank;
    }

    public ArrayList<String> getWordBank() {
        return this.wordbank;
    }
}
